/**
 * author: stephentian
 * email: stephentian@foxmail.com
 * day: 2018-10-22
 **/

// 这个项目是为了帮助开发者掌握 JavaScript 概念而创立的。它不是必备，但在未来学习（JavaScript）中，可以作为一篇指南。